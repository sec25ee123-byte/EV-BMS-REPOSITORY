"""Educational EV BMS monitoring prototype; simulation only."""
import argparse
import csv
import json
from pathlib import Path

# Illustrative demo thresholds only; not suitable for real battery protection.
CELL_VOLTAGE_MIN = 2.80
CELL_VOLTAGE_MAX = 4.20
CELL_TEMP_WARNING_C = 50.0
CELL_TEMP_CRITICAL_C = 60.0
PACK_CURRENT_MAX_A = 250.0
CELL_SPREAD_BALANCE_V = 0.020
CELL_SPREAD_WARNING_V = 0.100


def analyze_cells(cells, pack_current_a=0.0):
    """Analyze a list of {'cell_id', 'voltage_v', 'temperature_c'} dictionaries."""
    if not cells:
        raise ValueError("At least one cell reading is required.")

    warnings = []
    voltages = []
    critical = False

    for cell in cells:
        cid = str(cell["cell_id"])
        voltage = float(cell["voltage_v"])
        temp = float(cell["temperature_c"])
        voltages.append(voltage)

        if voltage < CELL_VOLTAGE_MIN:
            warnings.append({"cell_id": cid, "level": "critical", "code": "UNDERVOLTAGE"})
            critical = True
        elif voltage > CELL_VOLTAGE_MAX:
            warnings.append({"cell_id": cid, "level": "critical", "code": "OVERVOLTAGE"})
            critical = True

        if temp >= CELL_TEMP_CRITICAL_C:
            warnings.append({"cell_id": cid, "level": "critical", "code": "OVERTEMPERATURE"})
            critical = True
        elif temp >= CELL_TEMP_WARNING_C:
            warnings.append({"cell_id": cid, "level": "warning", "code": "HIGH_TEMPERATURE"})

    if abs(float(pack_current_a)) > PACK_CURRENT_MAX_A:
        warnings.append({"cell_id": "PACK", "level": "critical", "code": "OVERCURRENT"})
        critical = True

    spread = max(voltages) - min(voltages)
    if spread >= CELL_SPREAD_WARNING_V:
        warnings.append({"cell_id": "PACK", "level": "warning", "code": "HIGH_CELL_VOLTAGE_SPREAD"})

    highest = max(cells, key=lambda c: float(c["voltage_v"]))
    lowest = min(cells, key=lambda c: float(c["voltage_v"]))
    balancing = None
    if spread >= CELL_SPREAD_BALANCE_V:
        balancing = {
            "action": "SIMULATED_TRANSFER_RECOMMENDATION",
            "from_cell": str(highest["cell_id"]),
            "to_cell": str(lowest["cell_id"]),
            "voltage_spread_v": round(spread, 4),
            "note": "Recommendation only; no physical energy transfer is performed."
        }

    return {
        "cell_count": len(cells),
        "pack_current_a": float(pack_current_a),
        "cell_voltage_spread_v": round(spread, 4),
        "warnings": warnings,
        "balancing_recommendation": balancing,
        "request_isolation": critical,
        "scope_note": "Simulation only; not a real battery safety controller."
    }


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        row["voltage_v"] = float(row["voltage_v"])
        row["temperature_c"] = float(row["temperature_c"])
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="CSV with cell_id,voltage_v,temperature_c")
    parser.add_argument("--current", type=float, default=0.0, help="Simulated pack current in amperes")
    args = parser.parse_args()
    report = analyze_cells(read_csv(Path(args.input)), args.current)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
