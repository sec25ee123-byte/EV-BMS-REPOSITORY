import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from bms_monitor import analyze_cells


class TestBMSMonitor(unittest.TestCase):
    def test_normal_cells_no_isolation(self):
        cells = [
            {"cell_id": "A", "voltage_v": 3.8, "temperature_c": 30},
            {"cell_id": "B", "voltage_v": 3.81, "temperature_c": 31},
        ]
        report = analyze_cells(cells, 20)
        self.assertFalse(report["request_isolation"])
        self.assertEqual(report["warnings"], [])

    def test_overtemperature_requests_isolation(self):
        cells = [{"cell_id": "A", "voltage_v": 3.8, "temperature_c": 65}]
        report = analyze_cells(cells)
        self.assertTrue(report["request_isolation"])
        self.assertIn("OVERTEMPERATURE", [w["code"] for w in report["warnings"]])

    def test_balancing_recommendation_for_spread(self):
        cells = [
            {"cell_id": "A", "voltage_v": 4.0, "temperature_c": 30},
            {"cell_id": "B", "voltage_v": 3.9, "temperature_c": 30},
        ]
        report = analyze_cells(cells)
        self.assertEqual(report["balancing_recommendation"]["from_cell"], "A")
        self.assertEqual(report["balancing_recommendation"]["to_cell"], "B")

    def test_empty_input_rejected(self):
        with self.assertRaises(ValueError):
            analyze_cells([])


if __name__ == "__main__":
    unittest.main()
