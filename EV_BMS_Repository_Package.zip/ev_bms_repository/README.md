# Intelligent EV Battery Management System (BMS) — Prototype

A software prototype demonstrating cell-level monitoring, rule-based early warnings, a simulated active-balancing decision, and protective isolation alerts for a lithium-ion EV battery pack.

> **Safety and scope:** This repository is an educational simulation using sample data. It is not automotive-qualified and must not be used to control a real battery pack. Real EV protection requires validated sensors, hardware protection, contactors/fuses, fault-tolerant design, and professional safety testing. The balancing function here only recommends a transfer; it does not operate physical hardware.

## Features
- Per-cell voltage and temperature checks.
- Pack-level current checks.
- Early-warning flags for over/under-voltage, over-temperature, and unusual cell voltage spread.
- A simple active-balancing *recommendation* between the highest- and lowest-voltage cells.
- A protective-isolation alert when configured critical thresholds are exceeded.
- CSV sample data and automated unit tests.

## Requirements
- Python 3.10 or later
- No third-party packages required

## Quick start
```bash
python src/bms_monitor.py --input data/sample_cells.csv
python -m unittest discover -s tests -v
```

## Example output
The program prints a JSON report containing cell warnings, balancing recommendation, and whether the simulated pack should request isolation.

## Repository structure
```text
.
├── README.md
├── LICENSE
├── .gitignore
├── requirements.txt
├── src/
│   └── bms_monitor.py
├── data/
│   └── sample_cells.csv
├── tests/
│   └── test_bms_monitor.py
└── docs/
    ├── technical_design.md
    └── architecture.mmd
```

## Configuration
Thresholds are defined in `src/bms_monitor.py` as illustrative demonstration values. They are not recommended limits for any real chemistry or pack. Set thresholds only from the cell manufacturer's datasheet and a qualified safety review before any hardware implementation.

## Limitations and future work
- Uses fixed thresholds rather than validated state-of-health/state-of-charge estimation.
- Does not predict internal shorts or thermal runaway; it only flags measurable warning indicators in the sample inputs.
- Active balancing is represented as a recommendation, not a power-electronics controller.
- Future work: sensor integration, calibrated estimation algorithms, hardware-in-the-loop testing, independent safety controller, and verified contactor control.

## License
Released under the MIT License; see `LICENSE`.
